"""
Povo Civic Campus — Step 1: grafo pedonale pesato per pendenza e tempi da FBK/UniTn.

Costruisce un grafo pedonale DIRETTO dalla rete OSM (salita != discesa),
campiona le quote dal DEM 1 m, calcola i tempi di cammino con la funzione
di Tobler e misura i tempi da FBK e dal Polo UniTn verso i 41 servizi
della circoscrizione.

Input  (DATA_DIR):
  - osm_line2.geojson                          rete stradale/pedonale OSM
  - povo.tif                                   DEM 1 m, EPSG:25832
  - povo_umap_tutti_i_servizi_con_calcoli.csv  servizi circoscrizione
Output (OUT_DIR):
  - servizi_accessibilita_fbk.csv   tempi e fasce per servizio
  - graph.pkl                       grafo + tempi da FBK (per gli step 2 e 3)

Dipendenze: geopandas, networkx, rasterio, pyproj
  pip install geopandas networkx rasterio --break-system-packages
"""

import pickle
import warnings

import geopandas as gpd
import networkx as nx
import numpy as np
import pandas as pd
import rasterio
from pyproj import Transformer
from shapely.geometry import Point

warnings.filterwarnings("ignore")

# ----------------------------------------------------------------- parametri
DATA_DIR = "data"           # adattare alla struttura del repository
OUT_DIR = "data/processed"
CRS = "EPSG:25832"          # ETRS89 / UTM 32N, coerente con il DEM

# tipi di strada percorribili a piedi (chiave highway di OSM)
WALKABLE = {
    "footway", "path", "steps", "pedestrian", "residential", "service",
    "track", "unclassified", "tertiary", "secondary", "living_street",
    "cycleway",
}

SAMPLE_STEP_M = 25       # passo di densificazione/campionamento quota
STEPS_MAX_KMH = 1.8      # velocita' massima sulle scalinate
FLAT_KMH = 4.5           # baseline "terreno piatto" per il confronto
SNAP_MAX_INFO = None     # solo diagnostica: distanza di snap riportata in output

# origini (WGS84): FBK via Sommarive 18, Polo Ferrari / DISI
ORIGINS_WGS = {
    "FBK": (11.15153, 46.06722),
    "UniTn": (11.14980, 46.06700),
}

# fasce di classificazione (minuti)
BANDS = [0, 5, 10, 15, 20, np.inf]
BAND_LABELS = ["0-5 min", "5-10 min", "10-15 min", "15-20 min", ">20 min"]


def tobler_kmh(slope: float) -> float:
    """Velocita' di cammino (km/h) secondo la hiking function di Tobler.

    slope = dislivello/distanza (positivo in salita). Massimo ~6 km/h in
    leggera discesa (-5%), ~5 km/h in piano, decrescita esponenziale in salita.
    """
    return 6.0 * np.exp(-3.5 * abs(slope + 0.05))


def build_graph(net: gpd.GeoDataFrame, dem) -> nx.DiGraph:
    """Grafo diretto: ogni segmento genera due archi (andata/ritorno) con
    tempi diversi in funzione della pendenza campionata sul DEM."""

    def elev(xs, ys):
        vals = np.array([v[0] for v in dem.sample(zip(xs, ys))], dtype=float)
        vals[vals <= 0] = np.nan  # 0 = nodata implicito nel raster
        return vals

    G = nx.DiGraph()
    for _, row in net.iterrows():
        line = row.geometry
        is_steps = row.highway == "steps"
        n_pts = max(2, int(line.length // SAMPLE_STEP_M) + 1)
        pts = [line.interpolate(d) for d in np.linspace(0, line.length, n_pts)]
        xs = [p.x for p in pts]
        ys = [p.y for p in pts]
        zs = elev(xs, ys)

        for i in range(len(pts) - 1):
            a = (round(xs[i], 1), round(ys[i], 1))
            b = (round(xs[i + 1], 1), round(ys[i + 1], 1))
            d = float(np.hypot(xs[i + 1] - xs[i], ys[i + 1] - ys[i]))
            if d < 0.5:
                continue
            dz = (
                0.0
                if (np.isnan(zs[i]) or np.isnan(zs[i + 1]))
                else float(zs[i + 1] - zs[i])
            )
            for u, v, ddz in [(a, b, dz), (b, a, -dz)]:
                v_kmh = tobler_kmh(ddz / d)
                if is_steps:
                    v_kmh = min(v_kmh, STEPS_MAX_KMH)
                t = (d / 1000.0) / v_kmh * 60.0            # minuti, con pendenza
                t_flat = (d / 1000.0) / FLAT_KMH * 60.0    # minuti, piatto
                if G.has_edge(u, v):
                    if t < G[u][v]["t"]:
                        G[u][v].update(t=t, t_flat=t_flat, d=d)
                else:
                    G.add_edge(u, v, t=t, t_flat=t_flat, d=d)

    # si tiene solo la componente connessa principale
    comp = max(nx.weakly_connected_components(G), key=len)
    return G.subgraph(comp).copy()


def main() -> None:
    net = gpd.read_file(f"{DATA_DIR}/osm_line2.geojson").to_crs(CRS)
    net = net[net.highway.isin(WALKABLE)].copy()
    dem = rasterio.open(f"{DATA_DIR}/povo.tif")

    serv = pd.read_csv(f"{DATA_DIR}/povo_umap_tutti_i_servizi_con_calcoli.csv")
    serv_g = gpd.GeoDataFrame(
        serv,
        geometry=[Point(xy) for xy in zip(serv.longitudine, serv.latitudine)],
        crs="EPSG:4326",
    ).to_crs(CRS)

    G = build_graph(net, dem)
    print(f"Grafo: {G.number_of_nodes()} nodi, {G.number_of_edges()} archi diretti")

    nodes = np.array(list(G.nodes))

    def nearest_node(x, y):
        i = int(np.argmin((nodes[:, 0] - x) ** 2 + (nodes[:, 1] - y) ** 2))
        return tuple(nodes[i])

    tr = Transformer.from_crs("EPSG:4326", CRS, always_xy=True)
    origins = {
        k: nearest_node(*tr.transform(lon, lat))
        for k, (lon, lat) in ORIGINS_WGS.items()
    }

    # Dijkstra: andata (origine -> mondo), ritorno (mondo -> origine, grafo
    # inverso), tempo piatto e distanza metrica
    results = {}
    for name, o in origins.items():
        results[name] = (
            nx.single_source_dijkstra_path_length(G, o, weight="t"),
            nx.single_source_dijkstra_path_length(G.reverse(copy=False), o, weight="t"),
            nx.single_source_dijkstra_path_length(G, o, weight="t_flat"),
            nx.single_source_dijkstra_path_length(G, o, weight="d"),
        )

    rows = []
    for _, r in serv_g.iterrows():
        n = nearest_node(r.geometry.x, r.geometry.y)
        rec = dict(
            nome=r["nome"],
            categoria=r["mapcategory"],
            utenza=r["utenza_prevalente_calcolata"],
            funzione=r["funzione_relazionale_calcolata"],
            natura=r["natura_calcolata"],
            snap_m=round(float(np.hypot(n[0] - r.geometry.x, n[1] - r.geometry.y)), 1),
        )
        for name, (t_out, t_back, t_flat, d_m) in results.items():
            rec[f"t_{name}_andata"] = round(t_out.get(n, np.nan), 1)
            rec[f"t_{name}_ritorno"] = round(t_back.get(n, np.nan), 1)
            rec[f"t_{name}_piatto"] = round(t_flat.get(n, np.nan), 1)
            rec[f"dist_{name}_m"] = round(d_m.get(n, np.nan))
        rows.append(rec)

    df = pd.DataFrame(rows)
    df["t_FBK_medio"] = ((df.t_FBK_andata + df.t_FBK_ritorno) / 2).round(1)
    df["fascia_FBK"] = pd.cut(df.t_FBK_medio, BANDS, labels=BAND_LABELS)
    # nota: la penalita' confronta Tobler (max ~6 km/h) con la baseline a
    # 4.5 km/h, quindi puo' risultare negativa su percorsi favorevoli
    df["penalita_pendenza_%"] = ((df.t_FBK_medio / df.t_FBK_piatto - 1) * 100).round(0)
    df = df.sort_values("t_FBK_medio")

    df.to_csv(f"{OUT_DIR}/servizi_accessibilita_fbk.csv", index=False)
    with open(f"{OUT_DIR}/graph.pkl", "wb") as f:
        pickle.dump((G, results["FBK"][0], results["FBK"][1]), f)

    print(df[["nome", "fascia_FBK", "t_FBK_andata", "t_FBK_ritorno"]].head(15).to_string(index=False))
    print("\nFasce:", df.fascia_FBK.value_counts().sort_index().to_dict())


if __name__ == "__main__":
    main()
